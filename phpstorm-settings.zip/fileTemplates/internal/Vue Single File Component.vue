<template>
  <div></div>
</template>

<script>
export default {

  name: '${COMPONENT_NAME}',

  components: {},

  mixins: [],

  props: {},

  data: () => ({

  }),

  computed: {},

  watch: {},

  created () {

  },

  mounted () {

  },

  methods: {}

}
</script>

<style scoped>

</style>